
package net.mcreator.upgrade_mods.enchantment;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.enchantment.EnchantmentType;
import net.minecraft.enchantment.Enchantment;

import net.mcreator.upgrade_mods.item.NetherritearmorItem;
import net.mcreator.upgrade_mods.Upgrade116ModElements;

@Upgrade116ModElements.ModElement.Tag
public class SoulspeedEnchantment extends Upgrade116ModElements.ModElement {
	@ObjectHolder("upgrade1_16:soulspeed")
	public static final Enchantment enchantment = null;
	public SoulspeedEnchantment(Upgrade116ModElements instance) {
		super(instance, 79);
	}

	@Override
	public void initElements() {
		elements.enchantments.add(() -> new CustomEnchantment(EquipmentSlotType.MAINHAND).setRegistryName("soulspeed"));
	}
	public static class CustomEnchantment extends Enchantment {
		public CustomEnchantment(EquipmentSlotType... slots) {
			super(Enchantment.Rarity.UNCOMMON, EnchantmentType.ARMOR_FEET, slots);
		}

		@Override
		public int getMinLevel() {
			return 1;
		}

		@Override
		public int getMaxLevel() {
			return 3;
		}

		@Override
		public boolean canApplyAtEnchantingTable(ItemStack stack) {
			if (stack.getItem() == new ItemStack(NetherritearmorItem.boots, (int) (1)).getItem())
				return true;
			if (stack.getItem() == new ItemStack(Items.CHAINMAIL_BOOTS, (int) (1)).getItem())
				return true;
			if (stack.getItem() == new ItemStack(Items.DIAMOND_BOOTS, (int) (1)).getItem())
				return true;
			if (stack.getItem() == new ItemStack(Items.GOLDEN_BOOTS, (int) (1)).getItem())
				return true;
			if (stack.getItem() == new ItemStack(Items.LEATHER_BOOTS, (int) (1)).getItem())
				return true;
			if (stack.getItem() == new ItemStack(Items.IRON_BOOTS, (int) (1)).getItem())
				return true;
			return false;
		}

		@Override
		public boolean isTreasureEnchantment() {
			return true;
		}

		@Override
		public boolean isCurse() {
			return false;
		}

		@Override
		public boolean isAllowedOnBooks() {
			return true;
		}
	}
}

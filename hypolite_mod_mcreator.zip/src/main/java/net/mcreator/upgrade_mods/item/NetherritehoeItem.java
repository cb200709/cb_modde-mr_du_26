
package net.mcreator.upgrade_mods.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.item.HoeItem;
import net.minecraft.entity.player.PlayerEntity;

import net.mcreator.upgrade_mods.procedures.Hoe_adProcedure;
import net.mcreator.upgrade_mods.Upgrade116ModElements;

import java.util.Map;
import java.util.HashMap;

@Upgrade116ModElements.ModElement.Tag
public class NetherritehoeItem extends Upgrade116ModElements.ModElement {
	@ObjectHolder("upgrade1_16:netherritehoe")
	public static final Item block = null;
	public NetherritehoeItem(Upgrade116ModElements instance) {
		super(instance, 13);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new HoeItem(new IItemTier() {
			public int getMaxUses() {
				return 3021;
			}

			public float getEfficiency() {
				return 4f;
			}

			public float getAttackDamage() {
				return -1f;
			}

			public int getHarvestLevel() {
				return 4;
			}

			public int getEnchantability() {
				return 2;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(NetherriteingotItem.block, (int) (1)));
			}
		}, 0f, new Item.Properties().group(ItemGroup.TOOLS)) {
			@Override
			public boolean hasContainerItem() {
				return true;
			}

			@Override
			public ItemStack getContainerItem(ItemStack itemstack) {
				return new ItemStack(this);
			}

			@Override
			public void onCreated(ItemStack itemstack, World world, PlayerEntity entity) {
				super.onCreated(itemstack, world, entity);
				double x = entity.getPosX();
				double y = entity.getPosY();
				double z = entity.getPosZ();
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					Hoe_adProcedure.executeProcedure($_dependencies);
				}
			}
		}.setRegistryName("netherritehoe"));
	}
}

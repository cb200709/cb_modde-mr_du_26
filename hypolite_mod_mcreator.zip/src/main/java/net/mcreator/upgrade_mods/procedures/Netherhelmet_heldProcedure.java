package net.mcreator.upgrade_mods.procedures;

import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.upgrade_mods.Upgrade116ModElements;

import java.util.Map;

@Upgrade116ModElements.ModElement.Tag
public class Netherhelmet_heldProcedure extends Upgrade116ModElements.ModElement {
	public Netherhelmet_heldProcedure(Upgrade116ModElements instance) {
		super(instance, 17);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				System.err.println("Failed to load dependency entity for procedure Netherhelmet_held!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.NIGHT_VISION, (int) 1e+92, (int) 9));
	}
}
